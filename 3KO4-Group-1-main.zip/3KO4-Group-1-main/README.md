# 3KO4 Group #1

To Run the Python Code download the main.py file install bcyrpt by doing pip install bcrypt 
then do python main.py 
