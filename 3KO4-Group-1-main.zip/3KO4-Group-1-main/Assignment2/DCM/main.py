from login_screen import LoginScreen

if __name__ == "__main__":
    login_screen = LoginScreen()

